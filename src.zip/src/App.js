import React, { useState, useRef, useEffect } from 'react';
import './App.css';

const boardSize = 20;
const cellSize = 20; // px
const defaultBaseSpeed = 200; // ms
const speedIncrease = 5;

const initialSnake = [
  { x: 8 * cellSize, y: 10 * cellSize },
  { x: 7 * cellSize, y: 10 * cellSize },
  { x: 6 * cellSize, y: 10 * cellSize },
];

const getRandomFood = (snake) => {
  let food;
  while (true) {
    const x = Math.floor(Math.random() * boardSize) * cellSize;
    const y = Math.floor(Math.random() * boardSize) * cellSize;
    if (!snake.some(segment => segment.x === x && segment.y === y)) {
      food = { x, y };
      break;
    }
  }
  return food;
};

function App() {
  const [snake, setSnake] = useState(initialSnake);
  const [food, setFood] = useState(getRandomFood(initialSnake));
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [difficulty, setDifficulty] = useState('normal');
  const [highScores, setHighScores] = useState(() => ({
    easy: parseInt(localStorage.getItem('snakeHighScore_easy')) || 0,
    normal: parseInt(localStorage.getItem('snakeHighScore_normal')) || 0,
    hard: parseInt(localStorage.getItem('snakeHighScore_hard')) || 0
  }));
  const [waitingToStart, setWaitingToStart] = useState(true);

  const directionRef = useRef({ x: 1, y: 0 });
  const nextDirectionRef = useRef({ x: 1, y: 0 });
  const animationFrameId = useRef(null);
  const lastMoveTimeRef = useRef(performance.now());

  const eatingSegmentsRef = useRef([]);

  const getBaseSpeed = () => {
    switch (difficulty) {
      case 'easy': return 250;
      case 'hard': return 120;
      default: return defaultBaseSpeed;
    }
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (gameOver) return;

      const { x, y } = directionRef.current;
      let newDir = null;

      switch (e.key) {
        case 'ArrowUp': if (y !== 1) newDir = { x: 0, y: -1 }; break;
        case 'ArrowDown': if (y !== -1) newDir = { x: 0, y: 1 }; break;
        case 'ArrowLeft': if (x !== 1) newDir = { x: -1, y: 0 }; break;
        case 'ArrowRight': if (x !== -1) newDir = { x: 1, y: 0 }; break;
        default: return;
      }

      if (newDir) {
        nextDirectionRef.current = newDir;
        if (waitingToStart) setWaitingToStart(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameOver, waitingToStart]);

  useEffect(() => {
    if (gameOver || waitingToStart) return;

    const update = (time) => {
      const currentSpeed = Math.max(50, getBaseSpeed() - score * speedIncrease);
      const delta = time - lastMoveTimeRef.current;

      if (delta > currentSpeed) {
        lastMoveTimeRef.current = time;
        directionRef.current = nextDirectionRef.current;

        const dir = directionRef.current;
        const newHead = {
          x: snake[0].x + dir.x * cellSize,
          y: snake[0].y + dir.y * cellSize,
        };

        const collided =
          newHead.x < 0 || newHead.x >= boardSize * cellSize ||
          newHead.y < 0 || newHead.y >= boardSize * cellSize ||
          snake.some(segment => segment.x === newHead.x && segment.y === newHead.y);

        if (collided) {
          setGameOver(true);
          cancelAnimationFrame(animationFrameId.current);
          if (score > highScores[difficulty]) {
            const newHighScores = { ...highScores, [difficulty]: score };
            setHighScores(newHighScores);
            localStorage.setItem(`snakeHighScore_${difficulty}`, score.toString());
          }
          return;
        }

        let newSnake = [newHead, ...snake];
        if (newHead.x === food.x && newHead.y === food.y) {
          eatingSegmentsRef.current = [...eatingSegmentsRef.current, { x: newHead.x, y: newHead.y, timestamp: time }];
          setFood(getRandomFood(newSnake));
          setScore(prev => prev + 1);
          setSnake(newSnake);
        } else {
          newSnake.pop();
          setSnake(newSnake);
        }
      }

      animationFrameId.current = requestAnimationFrame(update);
    };

    animationFrameId.current = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animationFrameId.current);
  }, [snake, food, gameOver, waitingToStart, score, difficulty, highScores]);

  useEffect(() => {
    if (eatingSegmentsRef.current.length === 0) return;

    const interval = setInterval(() => {
      const now = performance.now();
      eatingSegmentsRef.current = eatingSegmentsRef.current.filter(seg => now - seg.timestamp < 400);
      setSnake(s => [...s]);
    }, 100);

    return () => clearInterval(interval);
  }, [snake]);

  const restartGame = () => {
    eatingSegmentsRef.current = [];
    const freshSnake = initialSnake.map(segment => ({ ...segment }));
    setSnake(freshSnake);
    setFood(getRandomFood(freshSnake));
    setScore(0);
    setGameOver(false);
    setWaitingToStart(true);
    directionRef.current = { x: 1, y: 0 };
    nextDirectionRef.current = { x: 1, y: 0 };
    lastMoveTimeRef.current = performance.now();
  };

  const handleDifficultyChange = (e) => {
    setDifficulty(e.target.value);
    restartGame();
  };

  const difficultyTranslations = {
    easy: 'Łatwy',
    normal: 'Średni',
    hard: 'Trudny'
  };

  return (
    <div className="container">
      <h1>Snake</h1>
      <div className="score">Wynik: {score} | Rekord ({difficultyTranslations[difficulty]}): {highScores[difficulty]}</div>
      <div className="controls">
        <label htmlFor="difficulty">Poziom trudności: </label>
        <select id="difficulty" value={difficulty} onChange={handleDifficultyChange} disabled={!gameOver && !waitingToStart}>
          <option value="easy">Łatwy</option>
          <option value="normal">Średni</option>
          <option value="hard">Trudny</option>
        </select>
      </div>
      <div
        className="board"
        style={{
          width: boardSize * cellSize,
          height: boardSize * cellSize,
          position: 'relative',
          margin: '40px auto 0 auto',
          display: 'grid',
          gridTemplateColumns: `repeat(${boardSize}, ${cellSize}px)`,
          gridTemplateRows: `repeat(${boardSize}, ${cellSize}px)`
        }}
      >
        {[...Array(boardSize * boardSize)].map((_, i) => (
          <div
            key={i}
            style={{
              backgroundColor: (Math.floor(i / boardSize) + (i % boardSize)) % 2 === 0 ? '#FED9ED' : '#E7BCDE',
              width: `${cellSize}px`,
              height: `${cellSize}px`
            }}
          />
        ))}
        {snake.map((segment, index) => {
          const isEating = eatingSegmentsRef.current.some(
            (seg) => seg.x === segment.x && seg.y === segment.y
          );

          return (
            <div
              key={`snake-${index}`}
              className={`snake ${index === 0 ? 'head' : ''} ${gameOver ? 'pulse' : ''} ${isEating ? 'eat-animation' : ''}`}
              style={{
                position: 'absolute',
                width: `${cellSize}px`,
                height: `${cellSize}px`,
                left: segment.x,
                top: segment.y,
              }}
            />
          );
        })}
        <div
          className="food"
          style={{
            width: cellSize,
            height: cellSize,
            position: 'absolute',
            left: food.x,
            top: food.y,
          }}
        />
      </div>
      {gameOver && (
        <div className="game-over">
          <p>Koniec gry! Twój wynik: {score}</p>
          <button onClick={restartGame}>Zagraj ponownie</button>
        </div>
      )}
      {!gameOver && waitingToStart && (
        <div className="press-start">
          <p>Naciśnij strzałkę, aby rozpocząć!</p>
        </div>
      )}
    </div>
  );
}

export default App;
